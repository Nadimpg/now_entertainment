package com.example.onsite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
