import 'package:get/get.dart';

class ForgetPassController extends GetxController {
  static ForgetPassController get to => Get.find();

  bool passObscure = true;
  bool confirmPassObscure = true;
}
