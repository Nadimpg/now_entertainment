import 'package:get/get.dart';

class ScheduleController extends GetxController {
 static ScheduleController get to => Get.find();
}
