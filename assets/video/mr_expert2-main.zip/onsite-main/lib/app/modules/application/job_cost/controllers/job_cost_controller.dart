import 'package:get/get.dart';

class JobCostController extends GetxController {
  static JobCostController get to => Get.find();
}
