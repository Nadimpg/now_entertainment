import 'package:get/get.dart';

class TimesheetController extends GetxController {
  static TimesheetController get to => Get.find();
  
}
