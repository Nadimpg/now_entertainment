class AppData {
  static List<String> category = [
    'All Jobs',
    'Cleaning',
    'Repairing',
    'Painting',
    'Plumbing',
    'Beauty',
  ];
  static List<String> level = [
    "Expert",
    "Intermediate",
  ];

  static List<String> setCategoryBudget = [
    'Choose Service',
    'Cleaning Service',
    'Plambing Service',
    'Beauty Service',
    'Mans Salon',
    'Painting',
    'Electronics',
    'Photography',
    'Car Repair',
  ];
  static List<String> location = [
    'Gulshan',
    'Banani',
    'Badda',
    'Mirpur',
    'Mohakhali',
  ];
  static List<String> userMonthlyIncome = [
    'Below BDT 1,000',
    'BDT 1,000 to BDT 5,000',
    'BDT 5,001 to BDT 10,000',
    'BDT 10,001 to BDT 20,000',
    'BDT 20,001 to BDT 50,000',
    'BDT 50,001 to BDT 100,000',
    'BDT 100,001 to BDT 200,000',
    'More than BDT 200,000',
  ];
  static List<String> userOccupation = [
    'Govt. Service ',
    'Private Service',
    'Business',
    'Self-employment ',
    'Student',
    'Housewife',
    'Retired',
    'Unemployed',
  ];
  static List<String> userTransaction = [
    'Bank',
    'Bkash',
    'Nagad',
  ];

  static List<String> userGender = [
    'Male',
    'Female',
  ];
  static List<String> userProposals = [
    'All Proposal',
  ];
}
