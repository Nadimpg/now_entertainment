const double kGapeSmall = 8;
const double kGapeReguler = 16;
const double kGapeMedium = 24;
const double kGapeLarge = 32;
const double kGapeXlarge = 42;
