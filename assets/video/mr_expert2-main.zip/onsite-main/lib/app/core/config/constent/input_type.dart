import 'package:flutter/services.dart';

class InputType {
  // var deme = FilteringTextInputFormatter.allow(RegExp(r'[0-9]'));
 static TextInputFormatter digitsOnly  = FilteringTextInputFormatter.digitsOnly;
}

