class Fonts {
  static const String primary = "SF_Pro";
  // static const String secondary = "Poppins";
}
